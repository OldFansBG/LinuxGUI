#ifndef WINDOWSCMDPANEL_H
#define WINDOWSCMDPANEL_H

#include <wx/wx.h>
#include <wx/process.h>

#ifdef __WINDOWS__
#include <windows.h>
#endif

class WindowsCmdPanel : public wxPanel
{
public:
    WindowsCmdPanel(wxWindow* parent);
    virtual ~WindowsCmdPanel();

private:
    void CreateCmdWindow();
    void OnSize(wxSizeEvent& event);

#ifdef __WINDOWS__
    HWND m_hwndCmd;
#endif

    wxDECLARE_EVENT_TABLE();
};

#endif // WINDOWSCMDPANEL_H