#ifndef GEAR_ICON_H
#define GEAR_ICON_H

// Declare the constant as extern
extern const char* GEAR_ICON_SVG;

#endif // GEAR_ICON_H