#include "SecondWindow.h"

wxBEGIN_EVENT_TABLE(SecondWindow, wxFrame)
    EVT_CLOSE(SecondWindow::OnClose)  // Bind the close event
wxEND_EVENT_TABLE()

SecondWindow::SecondWindow(wxWindow* parent, const wxString& title)
    : wxFrame(parent, wxID_ANY, title, wxDefaultPosition, wxSize(800, 600)), // Increased initial size
      m_cmdPanel(nullptr), m_terminalPanel(nullptr)
{
    wxPanel* panel = new wxPanel(this);
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);

    // OS text display at the top
    wxStaticText* osText = new wxStaticText(panel, wxID_ANY, title);
    mainSizer->Add(osText, 0, wxALIGN_CENTER | wxALL, 10); // Reduced padding

    // Detect OS and add appropriate panel
    OSDetector::OS currentOS = m_osDetector.GetCurrentOS();

    if (currentOS == OSDetector::OS::Windows) {
        m_cmdPanel = new WindowsCmdPanel(panel);
        mainSizer->Add(m_cmdPanel, 1, wxEXPAND | wxALL, 5);
    } else {
        m_terminalPanel = new LinuxTerminalPanel(panel);
        // Set minimum size that accommodates 80x24 terminal plus scrollbar and padding
        m_terminalPanel->SetMinSize(wxSize(680, 400));
        mainSizer->Add(m_terminalPanel, 1, wxEXPAND | wxALL, 5); // Reduced padding
    }

    panel->SetSizer(mainSizer);
    
    // Set minimum window size
    SetMinSize(wxSize(700, 500));
    
    // Center the window on screen
    CenterOnScreen();
    
    // Ensure proper layout
    panel->Layout();
    Layout();
}

void SecondWindow::OnClose(wxCloseEvent& event)
{
    if (GetParent()) {
        GetParent()->Show();
    }
    Destroy();  // Cleanup
}