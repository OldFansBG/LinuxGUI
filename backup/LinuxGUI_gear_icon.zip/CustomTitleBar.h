#ifndef CUSTOMTITLEBAR_H
#define CUSTOMTITLEBAR_H

#include <wx/wx.h>
#include "MyButton.h"

class CustomTitleBar : public wxPanel {
public:
    CustomTitleBar(wxWindow* parent);

private:
    void OnPaint(wxPaintEvent& event);
    void OnMouseLeftDown(wxMouseEvent& event);
    void OnMouseLeftUp(wxMouseEvent& event);
    void OnMouseMove(wxMouseEvent& event);
    void OnMouseCaptureLost(wxMouseCaptureLostEvent& event);
    void OnMouseLeave(wxMouseEvent& event);
    void OnMinimize(wxCommandEvent& event);
    void OnMaximize(wxCommandEvent& event);
    void OnClose(wxCommandEvent& event);
    
    void StyleButton(MyButton* button) {
        bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
        button->SetBackgroundColour(isDarkMode ? wxColour(51, 51, 51) : wxColour(251, 251, 251));
        button->SetForegroundColour(isDarkMode ? wxColour(255, 255, 255) : wxColour(0, 0, 0));
        button->SetHoverColor(isDarkMode ? wxColour(70, 70, 70) : wxColour(230, 230, 230));
    }
    
    wxPoint m_dragStart;
    wxPoint m_windowPos;
    bool m_isDragging;
    
    MyButton* m_minimizeButton;
    MyButton* m_maximizeButton;
    MyButton* m_closeButton;
    
    DECLARE_EVENT_TABLE()
};

#endif // CUSTOMTITLEBAR_H