#include "CustomStatusBar.h"

BEGIN_EVENT_TABLE(CustomStatusBar, wxPanel)
    EVT_PAINT(CustomStatusBar::OnPaint)
END_EVENT_TABLE()

CustomStatusBar::CustomStatusBar(wxWindow* parent)
    : wxPanel(parent, wxID_ANY, wxDefaultPosition, wxSize(-1, 24))
{
    SetBackgroundColour(parent->GetBackgroundColour());

    wxBoxSizer* sizer = new wxBoxSizer(wxHORIZONTAL);
    
    m_statusText = new wxStaticText(this, wxID_ANY, "Ready");
    m_statusText->SetForegroundColour(GetForegroundColour());
    
    sizer->Add(m_statusText, 0, wxALIGN_CENTER_VERTICAL | wxLEFT, 10);
    SetSizer(sizer);
}

void CustomStatusBar::SetStatusText(const wxString& text) {
    m_statusText->SetLabel(text);
}

void CustomStatusBar::OnPaint(wxPaintEvent& event) {
    wxPaintDC dc(this);
    
    wxColour lineColor = GetBackgroundColour().ChangeLightness(90);
    dc.SetPen(wxPen(lineColor));
    dc.DrawLine(0, 0, GetSize().GetWidth(), 0);
}