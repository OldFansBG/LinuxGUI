#include "CustomTitleBar.h"

enum {
    ID_MINIMIZE = wxID_HIGHEST + 1,
    ID_MAXIMIZE,
    ID_CLOSE_WINDOW
};

BEGIN_EVENT_TABLE(CustomTitleBar, wxPanel)
    EVT_PAINT(CustomTitleBar::OnPaint)
    EVT_LEFT_DOWN(CustomTitleBar::OnMouseLeftDown)
    EVT_LEFT_UP(CustomTitleBar::OnMouseLeftUp)
    EVT_MOTION(CustomTitleBar::OnMouseMove)
    EVT_MOUSE_CAPTURE_LOST(CustomTitleBar::OnMouseCaptureLost)
    EVT_LEAVE_WINDOW(CustomTitleBar::OnMouseLeave)
END_EVENT_TABLE()

CustomTitleBar::CustomTitleBar(wxWindow* parent)
    : wxPanel(parent, wxID_ANY, wxDefaultPosition, wxSize(-1, 32)),
      m_isDragging(false)
{
    SetBackgroundColour(parent->GetBackgroundColour());

    wxBoxSizer* sizer = new wxBoxSizer(wxHORIZONTAL);
    
    // Add title text
    wxStaticText* titleText = new wxStaticText(this, wxID_ANY, "ISO Analyzer",
                                              wxDefaultPosition, wxDefaultSize,
                                              wxALIGN_CENTER_HORIZONTAL);
    titleText->SetFont(wxFont(10, wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD));
    titleText->SetForegroundColour(GetForegroundColour());
    titleText->Bind(wxEVT_LEFT_DOWN, &CustomTitleBar::OnMouseLeftDown, this);
    titleText->Bind(wxEVT_LEFT_UP, &CustomTitleBar::OnMouseLeftUp, this);
    titleText->Bind(wxEVT_MOTION, &CustomTitleBar::OnMouseMove, this);
    
    // Add window control buttons
    m_minimizeButton = new MyButton(this, ID_MINIMIZE, "I:\\Files\\Desktop\\LinuxGUI\\minimize.png", 
                                  wxDefaultPosition, FromDIP(wxSize(46, 32)));
    m_maximizeButton = new MyButton(this, ID_MAXIMIZE, "I:\\Files\\Desktop\\LinuxGUI\\maximize.png", 
                                  wxDefaultPosition, FromDIP(wxSize(46, 32)));
    m_closeButton = new MyButton(this, ID_CLOSE_WINDOW, "I:\\Files\\Desktop\\LinuxGUI\\close.png", 
                               wxDefaultPosition, FromDIP(wxSize(46, 32)));
    
    // Set buttons to always be visible
    m_minimizeButton->SetAlwaysShowButton(true);
    m_maximizeButton->SetAlwaysShowButton(true);
    m_closeButton->SetAlwaysShowButton(true);
    
    StyleButton(m_minimizeButton);
    StyleButton(m_maximizeButton);
    StyleButton(m_closeButton);
    
    sizer->Add(titleText, 1, wxALIGN_CENTER_VERTICAL | wxLEFT, 10);
    sizer->Add(m_minimizeButton, 0, wxEXPAND);
    sizer->Add(m_maximizeButton, 0, wxEXPAND);
    sizer->Add(m_closeButton, 0, wxEXPAND);
    
    SetSizer(sizer);
    
    Bind(wxEVT_BUTTON, &CustomTitleBar::OnMinimize, this, ID_MINIMIZE);
    Bind(wxEVT_BUTTON, &CustomTitleBar::OnMaximize, this, ID_MAXIMIZE);
    Bind(wxEVT_BUTTON, &CustomTitleBar::OnClose, this, ID_CLOSE_WINDOW);
}

void CustomTitleBar::OnPaint(wxPaintEvent& event) {
    wxPaintDC dc(this);
    
    wxColour lineColor = GetBackgroundColour().ChangeLightness(90);
    dc.SetPen(wxPen(lineColor));
    dc.DrawLine(0, GetSize().GetHeight() - 1, GetSize().GetWidth(), GetSize().GetHeight() - 1);
}

void CustomTitleBar::OnMouseLeftDown(wxMouseEvent& event) {
    wxWindow* button = wxDynamicCast(event.GetEventObject(), wxWindow);
    if (button && (button == m_minimizeButton || button == m_maximizeButton || button == m_closeButton)) {
        event.Skip();
        return;
    }
    
    m_dragStart = ClientToScreen(event.GetPosition());
    wxFrame* frame = wxDynamicCast(GetParent(), wxFrame);
    if (frame) {
        wxPoint framePos = frame->GetPosition();
        m_windowPos = framePos;
    }
    m_isDragging = true;
    CaptureMouse();
}

void CustomTitleBar::OnMouseLeftUp(wxMouseEvent& event) {
    if (m_isDragging) {
        ReleaseMouse();
        m_isDragging = false;
    }
    event.Skip();
}

void CustomTitleBar::OnMouseMove(wxMouseEvent& event) {
    if (m_isDragging && event.Dragging() && event.LeftIsDown()) {
        wxPoint current = ClientToScreen(event.GetPosition());
        wxPoint diff = current - m_dragStart;
        
        wxFrame* frame = wxDynamicCast(GetParent(), wxFrame);
        if (frame) {
            wxPoint newPos = m_windowPos + diff;
            frame->Move(newPos);
        }
    }
    event.Skip();
}

void CustomTitleBar::OnMouseCaptureLost(wxMouseCaptureLostEvent& event) {
    m_isDragging = false;
}

void CustomTitleBar::OnMouseLeave(wxMouseEvent& event) {
    if (!event.LeftIsDown()) {
        m_isDragging = false;
        if (HasCapture()) {
            ReleaseMouse();
        }
    }
    event.Skip();
}

void CustomTitleBar::OnMinimize(wxCommandEvent& event) {
    wxFrame* frame = wxDynamicCast(GetParent(), wxFrame);
    if (frame) {
        frame->Iconize();
    }
}

void CustomTitleBar::OnMaximize(wxCommandEvent& event) {
    wxFrame* frame = wxDynamicCast(GetParent(), wxFrame);
    if (frame) {
        frame->Maximize(!frame->IsMaximized());
    }
}

void CustomTitleBar::OnClose(wxCommandEvent& event) {
    wxFrame* frame = wxDynamicCast(GetParent(), wxFrame);
    if (frame) {
        frame->Close();
    }
}