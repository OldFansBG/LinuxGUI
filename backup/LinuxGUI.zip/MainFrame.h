#ifndef MAINFRAME_H
#define MAINFRAME_H

#include <wx/wx.h>
#include <wx/statline.h>
#include <wx/bmpbuttn.h>
#include <yaml-cpp/yaml.h>
#include <vector>
#include <string>

class MainFrame : public wxFrame {
public:
    MainFrame(const wxString& title);

private:
    // Event handlers
    void OnBrowseISO(wxCommandEvent& event);
    void OnBrowseWorkDir(wxCommandEvent& event);
    void OnDetect(wxCommandEvent& event);
    void OnExtract(wxCommandEvent& event);
    void OnCancel(wxCommandEvent& event);
    void OnSettings(wxCommandEvent& event);

    // ISO Detection methods
    bool SearchReleaseFile(const wxString& isoPath, wxString& releaseContent);
    bool SearchGrubEnv(const wxString& isoPath, wxString& distributionName);
    wxString ExtractNameFromGrubEnv(const wxString& content);
    wxString DetectDistribution(const wxString& releaseContent);
    
    // Configuration methods
    bool LoadConfig();
    void CreateSettingsMenu();
    
    // UI Elements
    wxTextCtrl* m_isoPathCtrl;
    wxTextCtrl* m_distroCtrl;
    wxTextCtrl* m_projectNameCtrl;
    wxTextCtrl* m_versionCtrl;
    wxTextCtrl* m_workDirCtrl;
    wxGauge* m_progressGauge;
    wxStaticText* m_statusText;
    wxButton* m_settingsButton;

    // Helper methods for UI creation
    void CreateControls();
    wxPanel* CreateLogoPanel(wxWindow* parent);
    wxPanel* CreateDetectionPanel(wxWindow* parent);
    wxPanel* CreateProjectPanel(wxWindow* parent);
    wxPanel* CreateProgressPanel(wxWindow* parent);

    // Configuration data
    YAML::Node m_config;

    DECLARE_EVENT_TABLE()
};

#endif // MAINFRAME_H