//////////////////////////////////////////////////////////////////////////////
// Name:        String_wxsvg.h
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/01/19
// RCS-ID:      $Id: String_wxsvg.h,v 1.1 2007/09/21 06:47:34 etisserant Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#ifndef wxSVG_STRING_H
#define wxSVG_STRING_H

#include <wx/string.h>

#endif //wxSVG_STRING_H
