//////////////////////////////////////////////////////////////////////////////
// Name:        UIEvent.h
// Author:      Alex Thuering
// Created:     2016/08/05
// Copyright:   (c) 2016 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#ifndef wxSVG_UIEVENT_H
#define wxSVG_UIEVENT_H

class wxUIEvent {
public:
	wxUIEvent() {}
};

#endif // wxSVG_UIEVENT_H
