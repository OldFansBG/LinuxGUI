#include <wx/wx.h>
#include "include/wxSVG/wxsvg.h"

class SVGDrawingFrame : public wxFrame
{
public:
    SVGDrawingFrame(wxWindow* parent, const wxString& title) : wxFrame(parent, wxID_ANY, title, wxDefaultPosition, wxSize(800, 600))
    {
        wxPanel* panel = new wxPanel(this);

        // Create a wxSVGWindow to display the SVG
        m_svgWindow = new wxSVGWindow(panel, wxID_ANY);

        // Create an SVG document and add some shapes
        wxSVGDocument doc(800, 600);
        doc.AddCircle(400, 300, 100, wxSVGPaint(wxColour(255, 0, 0)), wxSVGPaint(wxColour(0, 255, 0)), 10);
        doc.AddRectangle(100, 100, 200, 200, wxSVGPaint(wxColour(0, 0, 255)), wxSVGPaint(wxColour(255, 255, 0)), 5);

        // Display the SVG document in the window
        m_svgWindow->SetDocument(&doc);

        // Create a sizer to hold the SVG window
        wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);
        sizer->Add(m_svgWindow, 1, wxEXPAND);
        panel->SetSizer(sizer);
    }

private:
    wxSVGWindow* m_svgWindow;
};

class SVGDrawingApp : public wxApp
{
public:
    virtual bool OnInit()
    {
        SVGDrawingFrame* frame = new SVGDrawingFrame(nullptr, "SVG Drawing");
        frame->Show(true);
        return true;
    }
};

wxIMPLEMENT_APP(SVGDrawingApp);