svg_home_dir = ".."
include_dir = svg_home_dir + "/include/wxSVG"
src_dir = svg_home_dir + "/src"
share_dir = svg_home_dir + "/share"

