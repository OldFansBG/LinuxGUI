//////////////////////////////////////////////////////////////////////////////
// Name:        SVGMarkerElement.cpp
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/05/10
// RCS-ID:      $Id: SVGMarkerElement.cpp,v 1.1.1.1 2005/05/10 17:51:39 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "SVGMarkerElement.h"

void wxSVGMarkerElement::SetOrientToAuto()
{

}

void wxSVGMarkerElement::SetOrientToAngle(const wxSVGAngle& angle)
{

}
