//////////////////////////////////////////////////////////////////////////////
// Name:        SVGTests.cpp
// Purpose:     
// Author:      Alex Thuering
// Created:     2005/04/29
// RCS-ID:      $Id: SVGTests.cpp,v 1.1.1.1 2005/05/10 17:51:39 ntalex Exp $
// Copyright:   (c) 2005 Alex Thuering
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "SVGTests.h"

bool wxSVGTests::HasExtension(const wxString& extension)
{
  return false;
}

