//////////////////////////////////////////////////////////////////////////////
// Name:        NodeList.cpp
// Purpose:     
// Author:      Edouard TISSERANT
// Created:     2005/04/29
// RCS-ID:      $Id:
// Copyright:   (c) 2005 Edouard TISSERANT
// Licence:     wxWindows licence
//////////////////////////////////////////////////////////////////////////////

#include "NodeList.h"
#include <wx/arrimpl.cpp>
WX_DEFINE_OBJARRAY(wxNodeList);

#include "NodeListCls.h"

