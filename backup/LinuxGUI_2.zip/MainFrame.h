#ifndef MAINFRAME_H
#define MAINFRAME_H

#include <wx/wx.h>
#include <wx/statline.h>
#include <wx/bmpbuttn.h>
#include <yaml-cpp/yaml.h>
#include <vector>
#include <string>
#include <wx/settings.h>
#include "MyButton.h"

#ifdef __WXMSW__
   #include <dwmapi.h>
   #include <windows.h>
   #pragma comment(lib, "dwmapi.lib")
   #pragma comment(lib, "advapi32.lib")
   
   #ifndef DWMWA_MICA_EFFECT
       #define DWMWA_MICA_EFFECT 1029
   #endif
#endif

class MainFrame : public wxFrame {
public:
   MainFrame(const wxString& title);

private:
   void OnBrowseISO(wxCommandEvent& event);
   void OnBrowseWorkDir(wxCommandEvent& event);
   void OnDetect(wxCommandEvent& event);
   void OnExtract(wxCommandEvent& event);
   void OnCancel(wxCommandEvent& event);
   void OnSettings(wxCommandEvent& event);

   bool SearchReleaseFile(const wxString& isoPath, wxString& releaseContent);
   bool SearchGrubEnv(const wxString& isoPath, wxString& distributionName);
   wxString ExtractNameFromGrubEnv(const wxString& content);
   wxString DetectDistribution(const wxString& releaseContent);
   
   bool LoadConfig();
   void CreateSettingsMenu();
   
   wxTextCtrl* m_isoPathCtrl;
   wxTextCtrl* m_distroCtrl;
   wxTextCtrl* m_projectNameCtrl;
   wxTextCtrl* m_versionCtrl;
   wxTextCtrl* m_workDirCtrl;
   wxGauge* m_progressGauge;
   wxStaticText* m_statusText;
   MyButton* m_settingsButton;

   void CreateControls();
   wxPanel* CreateLogoPanel(wxWindow* parent);
   wxPanel* CreateDetectionPanel(wxWindow* parent);
   wxPanel* CreateProjectPanel(wxWindow* parent);
   wxPanel* CreateProgressPanel(wxWindow* parent);

   void StylePanel(wxPanel* panel) {
       #ifdef __WXMSW__
           bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
           
           if (isDarkMode) {
               panel->SetBackgroundColour(wxColour(28, 28, 28));
               panel->SetForegroundColour(wxColour(255, 255, 255));
           } else {
               panel->SetBackgroundColour(wxColour(251, 251, 251));
               panel->SetForegroundColour(wxColour(0, 0, 0));
           }
           
           HWND hwnd = panel->GetHandle();
           if (hwnd) {
               MARGINS margins = {1, 1, 1, 1};
               DwmExtendFrameIntoClientArea(hwnd, &margins);
           }
       #endif
   }

   void StyleButton(wxButton* button, bool isPrimary = false) {
       bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
       if (isPrimary) {
           button->SetBackgroundColour(wxColour(0, 120, 212));
           button->SetForegroundColour(wxColour(255, 255, 255));
       } else if (isDarkMode) {
           button->SetBackgroundColour(wxColour(51, 51, 51));
           button->SetForegroundColour(wxColour(255, 255, 255));
       } else {
           button->SetBackgroundColour(wxColour(251, 251, 251));
           button->SetForegroundColour(wxColour(0, 0, 0));
       }
   }

   void StyleTextCtrl(wxTextCtrl* ctrl) {
       bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
       if (isDarkMode) {
           ctrl->SetBackgroundColour(wxColour(51, 51, 51));
           ctrl->SetForegroundColour(wxColour(255, 255, 255));
       } else {
           ctrl->SetBackgroundColour(wxColour(255, 255, 255));
           ctrl->SetForegroundColour(wxColour(0, 0, 0));
       }
   }

   void StyleText(wxStaticText* text) {
       bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
       if (isDarkMode) {
           text->SetForegroundColour(wxColour(255, 255, 255));
       } else {
           text->SetForegroundColour(wxColour(0, 0, 0));
       }
   }

   void StyleGauge(wxGauge* gauge) {
       bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
       if (isDarkMode) {
           gauge->SetBackgroundColour(wxColour(51, 51, 51));
       } else {
           gauge->SetBackgroundColour(wxColour(240, 240, 240));
       }
       gauge->SetForegroundColour(wxColour(0, 120, 212));
   }

   YAML::Node m_config;
   
   void OnThemeChanged() {
       bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
       wxColour bgColor = isDarkMode ? wxColour(32, 32, 32) : wxColour(243, 243, 243);
       wxColour fgColor = isDarkMode ? wxColour(255, 255, 255) : wxColour(0, 0, 0);
       
       SetBackgroundColour(bgColor);
       SetForegroundColour(fgColor);
       Refresh();
   }

   DECLARE_EVENT_TABLE()
};

#endif // MAINFRAME_H