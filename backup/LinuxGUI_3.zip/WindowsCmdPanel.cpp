#include "WindowsCmdPanel.h"

#ifdef __WINDOWS__
#include <wx/msw/private.h>
#endif

wxBEGIN_EVENT_TABLE(WindowsCmdPanel, wxPanel)
    EVT_SIZE(WindowsCmdPanel::OnSize)
wxEND_EVENT_TABLE()

WindowsCmdPanel::WindowsCmdPanel(wxWindow* parent)
    : wxPanel(parent) 
{
#ifdef __WINDOWS__
    m_hwndCmd = nullptr;
    CreateCmdWindow();
#endif
}

WindowsCmdPanel::~WindowsCmdPanel()
{
#ifdef __WINDOWS__
    if (m_hwndCmd)
    {
        ::SendMessage(m_hwndCmd, WM_CLOSE, 0, 0);
    }
#endif
}

void WindowsCmdPanel::CreateCmdWindow()
{
#ifdef __WINDOWS__
    STARTUPINFOW si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    ZeroMemory(&pi, sizeof(pi));

    // Create a command that will execute docker run when CMD starts
    // /K means keep the CMD window open after executing the command
    wchar_t cmdLine[] = L"cmd.exe /K docker run --privileged -it ubuntu /bin/bash";
    
    if (CreateProcessW(NULL, cmdLine, NULL, NULL, FALSE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi))
    {
        // Wait a bit longer for the console window to be created and docker to start
        Sleep(200);

        m_hwndCmd = FindWindowExW(NULL, NULL, L"ConsoleWindowClass", NULL);
        if (m_hwndCmd)
        {
            // Get the current window style
            LONG style = GetWindowLong(m_hwndCmd, GWL_STYLE);
            
            // Remove window border styles
            style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
            
            // Set the new style before changing the parent
            SetWindowLong(m_hwndCmd, GWL_STYLE, style);
            
            // Remove the extended window styles
            LONG exStyle = GetWindowLong(m_hwndCmd, GWL_EXSTYLE);
            exStyle &= ~(WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE);
            SetWindowLong(m_hwndCmd, GWL_EXSTYLE, exStyle);

            // Set the parent and show the window
            ::SetParent(m_hwndCmd, (HWND)GetHWND());
            ::ShowWindow(m_hwndCmd, SW_SHOW);
            
            // Force a redraw of the window
            ::SetWindowPos(m_hwndCmd, NULL, 0, 0, 0, 0, 
                          SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);

            // Bring window to front and give it focus
            ::SetForegroundWindow(m_hwndCmd);
            ::SetFocus(m_hwndCmd);
        }
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
#endif
}

void WindowsCmdPanel::OnSize(wxSizeEvent& event)
{
#ifdef __WINDOWS__
    if (m_hwndCmd)
    {
        wxSize size = GetClientSize();
        ::MoveWindow(m_hwndCmd, 0, 0, size.GetWidth(), size.GetHeight(), TRUE);
    }
#endif
    event.Skip();
}