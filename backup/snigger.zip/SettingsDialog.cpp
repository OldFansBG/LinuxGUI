// SettingsDialog.cpp
#include "SettingsDialog.h"
#include "MainFrame.h"

BEGIN_EVENT_TABLE(SettingsDialog, wxDialog)
    EVT_CHOICE(wxID_ANY, SettingsDialog::OnThemeChoice)
    EVT_BUTTON(wxID_OK, SettingsDialog::OnOK)
    EVT_BUTTON(wxID_CANCEL, SettingsDialog::OnCancel)
END_EVENT_TABLE()

SettingsDialog::SettingsDialog(wxWindow* parent)
    : wxDialog(parent, wxID_ANY, "Settings", 
              wxDefaultPosition, wxSize(400, 200),
              wxDEFAULT_DIALOG_STYLE)
{
    bool isDarkMode = parent->GetBackgroundColour().GetLuminance() < 0.5;
    StyleDialog(isDarkMode);
    CreateControls();
    Centre();
}

void SettingsDialog::CreateControls()
{
    bool isDarkMode = GetBackgroundColour().GetLuminance() < 0.5;
    
    wxPanel* mainPanel = new wxPanel(this);
    mainPanel->SetBackgroundColour(GetBackgroundColour());
    
    wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
    wxBoxSizer* themeSizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer* buttonSizer = new wxBoxSizer(wxHORIZONTAL);

    wxStaticText* themeLabel = new wxStaticText(mainPanel, wxID_ANY, "Theme:");
    StyleText(themeLabel, isDarkMode);
    
    wxArrayString themes;
    themes.Add("Light");
    themes.Add("Dark");
    
    m_themeChoice = new wxChoice(mainPanel, wxID_ANY, 
                                wxDefaultPosition, wxDefaultSize, themes);
    StyleChoice(m_themeChoice, isDarkMode);
    
    m_themeChoice->SetSelection(isDarkMode ? 1 : 0);

    themeSizer->Add(themeLabel, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 10);
    themeSizer->Add(m_themeChoice, 1, wxEXPAND);

    m_okButton = new wxButton(mainPanel, wxID_OK, "OK");
    m_cancelButton = new wxButton(mainPanel, wxID_CANCEL, "Cancel");
    
    StyleButton(m_okButton, isDarkMode, true);
    StyleButton(m_cancelButton, isDarkMode, false);

    buttonSizer->Add(m_okButton, 0, wxRIGHT, 5);
    buttonSizer->Add(m_cancelButton);

    mainSizer->Add(themeSizer, 0, wxEXPAND | wxALL, 10);
    mainSizer->AddStretchSpacer();
    mainSizer->Add(buttonSizer, 0, wxALIGN_RIGHT | wxALL, 10);

    mainPanel->SetSizer(mainSizer);

    wxBoxSizer* dialogSizer = new wxBoxSizer(wxVERTICAL);
    dialogSizer->Add(mainPanel, 1, wxEXPAND);
    SetSizer(dialogSizer);
}

void SettingsDialog::StyleDialog(bool isDarkMode)
{
    SetBackgroundColour(isDarkMode ? ThemeColors::DARK_BACKGROUND : ThemeColors::LIGHT_BACKGROUND);
    SetForegroundColour(isDarkMode ? ThemeColors::DARK_TEXT : ThemeColors::LIGHT_TEXT);
}

void SettingsDialog::StyleButton(wxButton* button, bool isDarkMode, bool isPrimary)
{
    if (isPrimary) {
        button->SetBackgroundColour(isDarkMode ? ThemeColors::DARK_PRIMARY_BG : ThemeColors::LIGHT_PRIMARY_BG);
        button->SetForegroundColour(isDarkMode ? ThemeColors::DARK_PRIMARY_TEXT : ThemeColors::LIGHT_PRIMARY_TEXT);
    } else {
        button->SetBackgroundColour(isDarkMode ? ThemeColors::DARK_BUTTON_BG : ThemeColors::LIGHT_BUTTON_BG);
        button->SetForegroundColour(isDarkMode ? ThemeColors::DARK_BUTTON_TEXT : ThemeColors::LIGHT_BUTTON_TEXT);
    }
}

void SettingsDialog::StyleChoice(wxChoice* choice, bool isDarkMode)
{
    choice->SetBackgroundColour(isDarkMode ? ThemeColors::DARK_BUTTON_BG : ThemeColors::LIGHT_BUTTON_BG);
    choice->SetForegroundColour(isDarkMode ? ThemeColors::DARK_TEXT : ThemeColors::LIGHT_TEXT);
}

void SettingsDialog::StyleText(wxStaticText* text, bool isDarkMode)
{
    text->SetForegroundColour(isDarkMode ? ThemeColors::DARK_TEXT : ThemeColors::LIGHT_TEXT);
}

void SettingsDialog::OnThemeChoice(wxCommandEvent& event)
{
    wxString theme = m_themeChoice->GetString(m_themeChoice->GetSelection());
    ApplyTheme(theme);
}

void SettingsDialog::OnOK(wxCommandEvent& event)
{
    wxString theme = m_themeChoice->GetString(m_themeChoice->GetSelection());
    ApplyTheme(theme);
    EndModal(wxID_OK);
}

void SettingsDialog::OnCancel(wxCommandEvent& event)
{
    EndModal(wxID_CANCEL);
}

void SettingsDialog::ApplyTheme(const wxString& theme)
{
    MainFrame* mainWindow = dynamic_cast<MainFrame*>(GetParent());
    if (!mainWindow) return;

    bool isDarkMode = (theme == "Dark");
    
    try {
        mainWindow->Freeze();
        
        // Set main window colors
        mainWindow->SetBackgroundColour(isDarkMode ? ThemeColors::DARK_BACKGROUND : ThemeColors::LIGHT_BACKGROUND);
        mainWindow->SetForegroundColour(isDarkMode ? ThemeColors::DARK_TEXT : ThemeColors::LIGHT_TEXT);
        
        // Update dialog appearance
        StyleDialog(isDarkMode);
        StyleButton(m_okButton, isDarkMode, true);
        StyleButton(m_cancelButton, isDarkMode, false);
        StyleChoice(m_themeChoice, isDarkMode);
        
        // Find and update titlebar and statusbar
        wxWindowList& children = mainWindow->GetChildren();
        for (wxWindow* child : children) {
            if (CustomTitleBar* titleBar = dynamic_cast<CustomTitleBar*>(child)) {
                titleBar->SetBackgroundColour(isDarkMode ? ThemeColors::DARK_TITLEBAR : ThemeColors::LIGHT_TITLEBAR);
                titleBar->SetForegroundColour(isDarkMode ? ThemeColors::DARK_TEXT : ThemeColors::LIGHT_PRIMARY_TEXT);
                titleBar->Refresh();
            }
            else if (CustomStatusBar* statusBar = dynamic_cast<CustomStatusBar*>(child)) {
                statusBar->SetBackgroundColour(isDarkMode ? ThemeColors::DARK_BACKGROUND : ThemeColors::LIGHT_BACKGROUND);
                statusBar->SetForegroundColour(isDarkMode ? ThemeColors::DARK_TEXT : ThemeColors::LIGHT_TEXT);
                statusBar->Refresh();
            }
        }
        
        // Call theme change after setting colors
        mainWindow->OnThemeChanged();
        
        mainWindow->Thaw();
        mainWindow->Refresh();
        Update();
    }
    catch (...) {
        if (mainWindow->IsFrozen()) {
            mainWindow->Thaw();
        }
        throw;
    }
}