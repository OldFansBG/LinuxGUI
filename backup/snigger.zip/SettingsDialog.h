// SettingsDialog.h
#ifndef SETTINGSDIALOG_H
#define SETTINGSDIALOG_H

#include <wx/wx.h>
#include "ThemeColors.h"
#include "CustomTitleBar.h"
#include "CustomStatusBar.h"

class SettingsDialog : public wxDialog 
{
public:
    explicit SettingsDialog(wxWindow* parent);

private:
    void CreateControls();
    void OnThemeChoice(wxCommandEvent& event);
    void OnOK(wxCommandEvent& event);
    void OnCancel(wxCommandEvent& event);
    void ApplyTheme(const wxString& theme);
    
    wxChoice* m_themeChoice;
    wxButton* m_okButton;
    wxButton* m_cancelButton;

    void StyleDialog(bool isDarkMode);
    void StyleButton(wxButton* button, bool isDarkMode, bool isPrimary = false);
    void StyleChoice(wxChoice* choice, bool isDarkMode);
    void StyleText(wxStaticText* text, bool isDarkMode);

    DECLARE_EVENT_TABLE()
};

#endif // SETTINGSDIALOG_H