#include "ISOExtractor.h"
#include <archive.h>
#include <archive_entry.h>
#include <filesystem>

namespace fs = std::filesystem;

ISOExtractor::ISOExtractor(const wxString& isoPath,
                         const wxString& destPath,
                         ProgressCallback progressCallback)
    : wxThread(wxTHREAD_DETACHED)
    , m_isoPath(isoPath)
    , m_destPath(destPath)
    , m_progressCallback(std::move(progressCallback))
    , m_stopRequested(false)
{
}

wxThread::ExitCode ISOExtractor::Entry() {
    if (ExtractTo(m_destPath.ToStdString())) {
        m_progressCallback(100, "Extraction completed successfully");
        return (ExitCode)0;
    }
    return (ExitCode)1;
}

bool ISOExtractor::ExtractTo(const std::string& destPath) {
    struct archive *archive;
    struct archive_entry *entry;
    int result;

    fs::create_directories(destPath);

    archive = archive_read_new();
    archive_read_support_format_iso9660(archive);

    if ((result = archive_read_open_filename(archive, m_isoPath.ToStdString().c_str(), 10240))) {
        m_progressCallback(0, "Could not open archive: " + 
                         wxString::FromUTF8(archive_error_string(archive)));
        return false;
    }

    while (archive_read_next_header(archive, &entry) == ARCHIVE_OK) {
        if (m_stopRequested) {
            m_progressCallback(0, "Extraction cancelled");
            archive_read_close(archive);
            archive_read_free(archive);
            return false;
        }

        const char* currentFile = archive_entry_pathname(entry);
        std::string fullOutPath = destPath + "/" + currentFile;

        m_progressCallback(50, "Extracting: " + wxString::FromUTF8(currentFile));

        archive_entry_set_pathname(entry, fullOutPath.c_str());

        if ((result = archive_read_extract(archive, entry, 
             ARCHIVE_EXTRACT_PERM | ARCHIVE_EXTRACT_TIME)) != ARCHIVE_OK) {
            m_progressCallback(0, "Extraction failed: " + 
                             wxString::FromUTF8(archive_error_string(archive)));
            archive_read_close(archive);
            archive_read_free(archive);
            return false;
        }
    }

    archive_read_close(archive);
    archive_read_free(archive);
    return true;
}