#include "WindowsCmdPanel.h"

#ifdef __WINDOWS__
#include <wx/msw/private.h>
#endif

wxBEGIN_EVENT_TABLE(WindowsCmdPanel, wxPanel)
    EVT_SIZE(WindowsCmdPanel::OnSize)
wxEND_EVENT_TABLE()

WindowsCmdPanel::WindowsCmdPanel(wxWindow* parent)
    : wxPanel(parent)
#ifdef __WINDOWS__
    , m_hwndCmd(nullptr)
#endif
{
}

WindowsCmdPanel::~WindowsCmdPanel()
{
#ifdef __WINDOWS__
    if (m_hwndCmd)
    {
        ::SendMessage(m_hwndCmd, WM_CLOSE, 0, 0);
    }
#endif
}

void WindowsCmdPanel::SetISOPath(const wxString& path)
{
    m_isoPath = path;
    if (!m_isoPath.IsEmpty()) {
        CreateCmdWindow();
    }
}

void WindowsCmdPanel::CreateCmdWindow()
{
#ifdef __WINDOWS__
    if (m_isoPath.IsEmpty()) {
        wxLogError("ISO path is empty. Cannot create command window.");
        return;
    }

    STARTUPINFOW si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;

    ZeroMemory(&pi, sizeof(pi));

    // Create Docker container
    wxArrayString output;
    wxExecute("docker run -d --privileged ubuntu:latest tail -f /dev/null", output, wxEXEC_SYNC);
    
    if (!output.IsEmpty()) {
        wxString containerId = output[0].Trim();
        
        // Initialize Docker transfer
        m_dockerTransfer = std::make_unique<DockerTransfer>(
            m_isoPath,
            std::bind(&WindowsCmdPanel::OnDockerProgress, this, 
                     std::placeholders::_1, std::placeholders::_2)
        );
        
        m_dockerTransfer->SetContainerId(containerId);
        
        // Transfer the ISO file
        if (m_dockerTransfer->TransferISOToContainer()) {
            wxLogMessage("Successfully transferred ISO to container");
            
            // Start interactive session
            wxString dockerExec = wxString::Format("docker exec -it %s bash", containerId);
            wchar_t cmdLine[1024];
            swprintf(cmdLine, 1024, L"cmd.exe /K %s", dockerExec.wc_str());
            
            if (CreateProcessW(NULL, cmdLine, NULL, NULL, FALSE, CREATE_NEW_CONSOLE, NULL, NULL, &si, &pi))
            {
                Sleep(200);
                m_hwndCmd = FindWindowExW(NULL, NULL, L"ConsoleWindowClass", NULL);
                if (m_hwndCmd)
                {
                    LONG style = GetWindowLong(m_hwndCmd, GWL_STYLE);
                    style &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
                    SetWindowLong(m_hwndCmd, GWL_STYLE, style);
                    
                    LONG exStyle = GetWindowLong(m_hwndCmd, GWL_EXSTYLE);
                    exStyle &= ~(WS_EX_CLIENTEDGE | WS_EX_WINDOWEDGE);
                    SetWindowLong(m_hwndCmd, GWL_EXSTYLE, exStyle);

                    ::SetParent(m_hwndCmd, (HWND)GetHWND());
                    ::ShowWindow(m_hwndCmd, SW_SHOW);
                    ::SetWindowPos(m_hwndCmd, NULL, 0, 0, 0, 0, 
                                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
                    ::SetForegroundWindow(m_hwndCmd);
                    ::SetFocus(m_hwndCmd);
                }
                CloseHandle(pi.hProcess);
                CloseHandle(pi.hThread);
            }
        } else {
            wxLogError("Failed to transfer ISO to container");
        }
    } else {
        wxLogError("Failed to create Docker container");
    }
#endif
}

void WindowsCmdPanel::OnSize(wxSizeEvent& event)
{
#ifdef __WINDOWS__
    if (m_hwndCmd)
    {
        wxSize size = GetClientSize();
        ::MoveWindow(m_hwndCmd, 0, 0, size.GetWidth(), size.GetHeight(), TRUE);
    }
#endif
    event.Skip();
}

void WindowsCmdPanel::OnDockerProgress(int progress, const wxString& status)
{
    wxLogMessage(status);
}