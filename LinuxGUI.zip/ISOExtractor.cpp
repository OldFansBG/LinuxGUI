#include "ISOExtractor.h"
#include <archive.h>
#include <archive_entry.h>
#include <filesystem>

namespace fs = std::filesystem;

ISOExtractor::ISOExtractor(const wxString& isoPath,
                         const wxString& destPath,
                         ProgressCallback progressCallback)
    : wxThread(wxTHREAD_DETACHED)
    , m_isoPath(isoPath)
    , m_destPath(destPath)
    , m_progressCallback(std::move(progressCallback))
    , m_stopRequested(false)
{
}

wxThread::ExitCode ISOExtractor::Entry() {
    if (ExtractTo(m_destPath.ToStdString())) {
        m_progressCallback(100, "Extraction completed successfully");
        return (ExitCode)0;
    }
    return (ExitCode)1;
}

bool ISOExtractor::ExtractTo(const std::string& destPath) {
    // First pass: Extract everything except hard links
    struct archive *archive = archive_read_new();
    archive_read_support_format_iso9660(archive);
    archive_read_extract_set_options(archive, "no-same-owner");
    
    if (archive_read_open_filename(archive, m_isoPath.ToStdString().c_str(), 10240) != ARCHIVE_OK) {
        m_progressCallback(0, "Could not open archive: " + 
                         wxString::FromUTF8(archive_error_string(archive)));
        return false;
    }

    struct archive_entry *entry;
    std::vector<std::pair<std::string, std::string>> hardlinks;

    // First pass: Extract non-hardlink files
    while (archive_read_next_header(archive, &entry) == ARCHIVE_OK) {
        if (m_stopRequested) {
            archive_read_close(archive);
            archive_read_free(archive);
            return false;
        }

        const char* currentFile = archive_entry_pathname(entry);
        std::string fullOutPath = destPath + "/" + currentFile;

        // If it's a hardlink, store it for second pass
        const char* hardlink = archive_entry_hardlink(entry);
        if (hardlink) {
            hardlinks.push_back({std::string(hardlink), std::string(currentFile)});
            continue;
        }

        archive_entry_set_pathname(entry, fullOutPath.c_str());
        
        if (archive_read_extract(archive, entry, 
            ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM) != ARCHIVE_OK) {
            m_progressCallback(0, "Extraction failed: " + 
                             wxString::FromUTF8(archive_error_string(archive)));
            archive_read_close(archive);
            archive_read_free(archive);
            return false;
        }
    }

    archive_read_close(archive);
    archive_read_free(archive);

    // Second pass: Create hard links
    for (const auto& [target, link] : hardlinks) {
        std::string targetPath = destPath + "/" + target;
        std::string linkPath = destPath + "/" + link;
        
        #ifdef _WIN32
            CreateHardLink(linkPath.c_str(), targetPath.c_str(), nullptr);
        #else
            link(targetPath.c_str(), linkPath.c_str());
        #endif
    }

    return true;
}